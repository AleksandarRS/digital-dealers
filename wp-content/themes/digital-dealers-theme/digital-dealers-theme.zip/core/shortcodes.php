<?php 
/**
 * Theme shortcodes are registered here. It's corresponding functions are located in functions.php file
 * 
 */
add_shortcode( 'lf_social', 'the_social_links' );

?>